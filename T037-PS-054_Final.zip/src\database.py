import sqlite3
from pathlib import Path


def create_database(db_path):
    """Create the database and its tables."""
    db_path = Path(db_path)
    db_path.parent.mkdir(parents=True, exist_ok=True)

    connection = sqlite3.connect(db_path)

    connection.execute("""
        CREATE TABLE IF NOT EXISTS wallets (
            wallet_id INTEGER PRIMARY KEY AUTOINCREMENT,
            owner_name TEXT NOT NULL,
            balance REAL NOT NULL DEFAULT 0
        )
    """)

    connection.execute("""
        CREATE TABLE IF NOT EXISTS transactions (
            transaction_id INTEGER PRIMARY KEY AUTOINCREMENT,
            wallet_id INTEGER NOT NULL,
            transaction_type TEXT NOT NULL,
            amount REAL NOT NULL,
            created_at TEXT DEFAULT CURRENT_TIMESTAMP
        )
    """)

    connection.execute("""
        CREATE TABLE IF NOT EXISTS gift_cards (
            code TEXT PRIMARY KEY,
            balance REAL NOT NULL,
            redeemed INTEGER NOT NULL DEFAULT 0
        )
    """)

    connection.commit()
    connection.close()


def create_wallet(db_path, owner_name):
    """Create a wallet and return its ID."""
    connection = sqlite3.connect(db_path)
    cursor = connection.execute(
        "INSERT INTO wallets (owner_name) VALUES (?)", (owner_name,)
    )
    connection.commit()
    wallet_id = cursor.lastrowid
    connection.close()
    return wallet_id


def get_wallet_balance(db_path, wallet_id):
    connection = sqlite3.connect(db_path)
    row = connection.execute(
        "SELECT balance FROM wallets WHERE wallet_id = ?", (wallet_id,)
    ).fetchone()
    connection.close()
    return row[0]


def deposit(db_path, wallet_id, amount):
    connection = sqlite3.connect(db_path)
    connection.execute(
        "UPDATE wallets SET balance = balance + ? WHERE wallet_id = ?",
        (amount, wallet_id),
    )
    connection.execute(
        "INSERT INTO transactions (wallet_id, transaction_type, amount) "
        "VALUES (?, 'deposit', ?)",
        (wallet_id, amount),
    )
    connection.commit()
    connection.close()


def withdraw(db_path, wallet_id, amount):
    connection = sqlite3.connect(db_path)
    balance = connection.execute(
        "SELECT balance FROM wallets WHERE wallet_id = ?", (wallet_id,)
    ).fetchone()[0]
    if amount > balance:
        connection.close()
        raise ValueError("Insufficient funds")
    connection.execute(
        "UPDATE wallets SET balance = balance - ? WHERE wallet_id = ?",
        (amount, wallet_id),
    )
    connection.execute(
        "INSERT INTO transactions (wallet_id, transaction_type, amount) "
        "VALUES (?, 'withdrawal', ?)",
        (wallet_id, amount),
    )
    connection.commit()
    connection.close()


def get_transaction_history(db_path, wallet_id):
    """Return (transaction_type, amount, created_at) rows, oldest first."""
    connection = sqlite3.connect(db_path)
    rows = connection.execute(
        "SELECT transaction_type, amount, created_at FROM transactions "
        "WHERE wallet_id = ? ORDER BY transaction_id",
        (wallet_id,),
    ).fetchall()
    connection.close()
    return rows


def create_gift_card(db_path, code, amount):
    """Create a gift card with a unique code and a starting balance."""
    if amount <= 0:
        raise ValueError("Gift card amount must be positive")
    connection = sqlite3.connect(db_path)
    try:
        connection.execute(
            "INSERT INTO gift_cards (code, balance) VALUES (?, ?)",
            (code, amount),
        )
        connection.commit()
    except sqlite3.IntegrityError:
        raise ValueError("Gift card code already exists")
    finally:
        connection.close()


def get_gift_card_balance(db_path, code):
    connection = sqlite3.connect(db_path)
    row = connection.execute(
        "SELECT balance FROM gift_cards WHERE code = ?", (code,)
    ).fetchone()
    connection.close()
    if row is None:
        raise ValueError("Gift card not found")
    return row[0]


def redeem_gift_card(db_path, code, wallet_id):
    """Move the full gift card balance into a wallet. Works only once."""
    connection = sqlite3.connect(db_path)
    try:
        row = connection.execute(
            "SELECT balance, redeemed FROM gift_cards WHERE code = ?", (code,)
        ).fetchone()
        if row is None:
            raise ValueError("Gift card not found")
        balance, redeemed = row
        if redeemed:
            raise ValueError("Gift card already redeemed")

        connection.execute(
            "UPDATE gift_cards SET balance = 0, redeemed = 1 WHERE code = ?",
            (code,),
        )
        connection.execute(
            "UPDATE wallets SET balance = balance + ? WHERE wallet_id = ?",
            (balance, wallet_id),
        )
        connection.execute(
            "INSERT INTO transactions (wallet_id, transaction_type, amount) "
            "VALUES (?, 'gift_card_redeem', ?)",
            (wallet_id, balance),
        )
        connection.commit()
    finally:
        connection.close()
def transfer(db_path, from_wallet_id, to_wallet_id, amount):
    """Withdraw from one wallet and deposit into another."""
    withdraw(db_path, from_wallet_id, amount)
    deposit(db_path, to_wallet_id, amount)

def expire_gift_card(db_path, code):
    """Expire a gift card and return the unused balance (breakage)."""
    connection = sqlite3.connect(db_path)
    try:
        row = connection.execute(
            "SELECT balance, redeemed FROM gift_cards WHERE code = ?", (code,)
        ).fetchone()
        if row is None:
            raise ValueError("Gift card not found")
        balance, redeemed = row
        if redeemed:
            raise ValueError("Gift card already redeemed or expired")

        # Set balance to 0 and mark as redeemed/expired
        connection.execute(
            "UPDATE gift_cards SET balance = 0, redeemed = 1 WHERE code = ?",
            (code,),
        )
        connection.commit()
        return balance  # This returned balance is the "breakage"
    finally:
        connection.close()
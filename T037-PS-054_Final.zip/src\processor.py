from src.database import (
    create_wallet,
    get_wallet_balance,
    deposit,
    withdraw,
    create_gift_card,
    redeem_gift_card,
    transfer,
    expire_gift_card
)


def process_line(db_path, line):
    parts = line.strip().split()
    if not parts:
        return ""
    
    command = parts[0]
    
    try:
        if command == "CREATE_WALLET":
            wallet_id = create_wallet(db_path, parts[1])
            return f"OK wallet {wallet_id} created for {parts[1]}"
            
        if command == "BALANCE":
            balance = get_wallet_balance(db_path, int(parts[1]))
            return f"OK wallet {parts[1]} balance {balance}"
            
        if command == "DEPOSIT":
            deposit(db_path, int(parts[1]), float(parts[2]))
            return f"OK deposited {parts[2]} into wallet {parts[1]}"
            
        if command == "WITHDRAW":
            if get_wallet_balance(db_path, int(parts[1])) < float(parts[2]):
                return "ERROR insufficient funds"
            withdraw(db_path, int(parts[1]), float(parts[2]))
            return f"OK withdrew {parts[2]} from wallet {parts[1]}"
            
        if command == "TRANSFER":
            if get_wallet_balance(db_path, int(parts[1])) < float(parts[3]):
                return "ERROR insufficient funds"
            transfer(db_path, int(parts[1]), int(parts[2]), float(parts[3]))
            return f"OK transferred {parts[3]} from wallet {parts[1]} to wallet {parts[2]}"

        if command == "CREATE_GIFT_CARD":
            create_gift_card(db_path, int(parts[1]), float(parts[2]))
            return f"OK gift card {parts[1]} created with balance {parts[2]}"

        if command == "REDEEM_GIFT_CARD":
            redeem_gift_card(db_path, int(parts[1]), int(parts[2]))
            return f"OK redeemed gift card {parts[2]} into wallet {parts[1]}"
        if command == "EXPIRE_GIFT_CARD":
            breakage = expire_gift_card(db_path, parts[1])
            return f"OK gift card {parts[1]} expired with breakage {breakage}"
        return f"ERROR unknown command {command}"
    except (ValueError, IndexError, TypeError) as error:
        return f"ERROR {error}"
def process_file(db_path, input_path, output_path):
    """Run every command in input_path and write results to output_path."""
    results = []
    with open(input_path) as f:
        for line in f:
            line = line.strip()
            if line:
                results.append(process_line(db_path, line))
    with open(output_path, "w") as f:
        f.write("\n".join(results) + "\n")
    return results
import pytest

from src.database import (
    create_database,
    create_wallet,
    get_wallet_balance,
    deposit,
    withdraw,
    get_transaction_history,
    create_gift_card,
    get_gift_card_balance,
    redeem_gift_card,
)


def test_create_database(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)
    assert db_path.exists()


def test_create_wallet(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)
    wallet_id = create_wallet(db_path, "Alice")
    assert wallet_id == 1


def test_get_wallet_balance(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)
    wallet_id = create_wallet(db_path, "Alice")
    balance = get_wallet_balance(db_path, wallet_id)
    assert balance == 0.0


def test_deposit(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)
    wallet_id = create_wallet(db_path, "Alice")
    deposit(db_path, wallet_id, 100)
    assert get_wallet_balance(db_path, wallet_id) == 100.0


def test_withdraw(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)
    wallet_id = create_wallet(db_path, "Alice")
    deposit(db_path, wallet_id, 100)
    withdraw(db_path, wallet_id, 30)
    assert get_wallet_balance(db_path, wallet_id) == 70.0


def test_transaction_history(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)

    wallet_id = create_wallet(db_path, "Alice")

    deposit(db_path, wallet_id, 100)
    withdraw(db_path, wallet_id, 30)

    history = get_transaction_history(db_path, wallet_id)

    assert len(history) == 2
    assert history[0][0] == "deposit"
    assert history[0][1] == 100
    assert history[1][0] == "withdrawal"
    assert history[1][1] == 30


def test_withdraw_insufficient_funds(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)

    wallet_id = create_wallet(db_path, "Alice")
    deposit(db_path, wallet_id, 50)

    with pytest.raises(ValueError):
        withdraw(db_path, wallet_id, 80)

    assert get_wallet_balance(db_path, wallet_id) == 50.0
    assert len(get_transaction_history(db_path, wallet_id)) == 1


def test_create_gift_card(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)

    create_gift_card(db_path, "GC-100", 50)

    assert get_gift_card_balance(db_path, "GC-100") == 50.0


def test_redeem_gift_card(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)
    wallet_id = create_wallet(db_path, "Alice")
    create_gift_card(db_path, "GC-100", 50)

    redeem_gift_card(db_path, "GC-100", wallet_id)

    assert get_wallet_balance(db_path, wallet_id) == 50.0
    assert get_gift_card_balance(db_path, "GC-100") == 0.0
    history = get_transaction_history(db_path, wallet_id)
    assert history[0][0] == "gift_card_redeem"
    assert history[0][1] == 50


def test_redeem_gift_card_twice_fails(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)
    wallet_id = create_wallet(db_path, "Alice")
    create_gift_card(db_path, "GC-100", 50)
    redeem_gift_card(db_path, "GC-100", wallet_id)

    with pytest.raises(ValueError):
        redeem_gift_card(db_path, "GC-100", wallet_id)

    assert get_wallet_balance(db_path, wallet_id) == 50.0


def test_redeem_unknown_gift_card(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)
    wallet_id = create_wallet(db_path, "Alice")

    with pytest.raises(ValueError):
        redeem_gift_card(db_path, "NOPE", wallet_id)
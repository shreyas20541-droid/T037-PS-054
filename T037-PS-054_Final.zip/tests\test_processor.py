from src.database import create_database
from src.processor import process_file


def test_process_file(tmp_path):
    db_path = tmp_path / "wallet.db"
    create_database(db_path)

    input_path = tmp_path / "commands.txt"
    input_path.write_text(
        "CREATE_WALLET Alice\n"
        "DEPOSIT 1 100\n"
        "WITHDRAW 1 30\n"
        "WITHDRAW 1 500\n"
        "BALANCE 1\n"
    )
    output_path = tmp_path / "report.txt"

    results = process_file(db_path, input_path, output_path)

    assert results[0].startswith("OK wallet 1 created")
    assert results[3].startswith("ERROR")
    assert results[4] == "OK wallet 1 balance 70.0"
    assert output_path.exists()